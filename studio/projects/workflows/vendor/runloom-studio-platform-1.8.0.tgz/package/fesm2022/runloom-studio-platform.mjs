import * as i0 from '@angular/core';
import { signal, computed, Injectable, inject, DestroyRef, viewChild, effect, Component, EventEmitter, ElementRef, ChangeDetectorRef, Output, Input, ViewChild } from '@angular/core';
import Keycloak from 'keycloak-js';
import { from, switchMap } from 'rxjs';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';

// Derive redirects from the current origin, never a caller-supplied return URL.
function authReturnUrl(current) {
    const url = new URL(current);
    for (const key of ['code', 'state', 'session_state', 'iss', 'error', 'error_description', 'signedOut']) {
        url.searchParams.delete(key);
    }
    return url.toString();
}

// Workspace preferences are optional; unavailable storage must not block rendering.
function readPreference(key) {
    try {
        return localStorage.getItem(key) || '';
    }
    catch {
        return '';
    }
}
function storePreference(key, value) {
    try {
        localStorage.setItem(key, value);
    }
    catch { }
}
class AuthService {
    keycloak;
    config;
    ready = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ready" }] : /* istanbul ignore next */ []));
    signedIn = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "signedIn" }] : /* istanbul ignore next */ []));
    profile = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "profile" }] : /* istanbul ignore next */ []));
    organizationId = signal(readPreference('runloom-org'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "organizationId" }] : /* istanbul ignore next */ []));
    teamId = signal(readPreference('runloom-team'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "teamId" }] : /* istanbul ignore next */ []));
    organizations = computed(() => this.profile()?.organizations || [], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "organizations" }] : /* istanbul ignore next */ []));
    organization = computed(() => this.organizations().find((o) => o.id === this.organizationId()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "organization" }] : /* istanbul ignore next */ []));
    team = computed(() => this.organization()?.teams.find((t) => t.id === this.teamId()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "team" }] : /* istanbul ignore next */ []));
    canEdit = computed(() => !!this.team() && this.team()?.role !== 'viewer', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canEdit" }] : /* istanbul ignore next */ []));
    orgAdmin = computed(() => ['owner', 'admin'].includes(this.organization()?.role || ''), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orgAdmin" }] : /* istanbul ignore next */ []));
    teamAdmin = computed(() => this.team()?.role === 'admin', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "teamAdmin" }] : /* istanbul ignore next */ []));
    async initialize() {
        const response = await fetch('/api/v1/auth/config');
        if (!response.ok)
            throw new Error('Sign-in service is unavailable.');
        this.config = (await response.json());
        this.keycloak = new Keycloak(this.config);
        const authenticated = await this.keycloak.init({
            onLoad: 'login-required',
            pkceMethod: 'S256',
            checkLoginIframe: false,
            responseMode: 'query',
            redirectUri: authReturnUrl(window.location.href),
        });
        if (authenticated)
            await this.refresh();
        this.signedIn.set(authenticated);
        this.ready.set(true);
    }
    async bearer() {
        if (!this.keycloak?.authenticated)
            throw new Error('Please sign in.');
        try {
            await this.keycloak.updateToken(30);
            return this.keycloak.token;
        }
        catch {
            this.signedIn.set(false);
            this.profile.set(undefined);
            throw new Error('Your session expired. Please sign in again.');
        }
    }
    async request(path, body, method) {
        const response = await fetch(path, {
            method: method || (body === undefined ? 'GET' : 'POST'),
            headers: {
                Authorization: 'Bearer ' + (await this.bearer()),
                'Content-Type': 'application/json',
            },
            body: body === undefined ? undefined : JSON.stringify(body),
        });
        if (!response.ok) {
            const message = await response.json().catch(() => ({}));
            throw new Error(message.detail || message.error || 'Request failed (' + response.status + ')');
        }
        return response.json();
    }
    async refresh() {
        this.profile.set(await this.request('/api/v1/studio/me'));
        if (!this.organization())
            this.selectOrganization(this.organizations()[0]?.id || '');
        else if (!this.team())
            this.selectTeam(this.organization()?.teams[0]?.id || '');
    }
    selectOrganization(id) {
        this.organizationId.set(id);
        storePreference('runloom-org', id);
        this.selectTeam(this.organization()?.teams[0]?.id || '');
    }
    selectTeam(id) {
        this.teamId.set(id);
        storePreference('runloom-team', id);
    }
    login(google = false) {
        return this.keycloak.login({
            redirectUri: authReturnUrl(window.location.href),
            ...(google ? { idpHint: 'google' } : {}),
        });
    }
    register() {
        return this.keycloak.register({ redirectUri: authReturnUrl(window.location.href) });
    }
    logout() {
        return this.keycloak.logout({ redirectUri: window.location.origin + '/' });
    }
    forgotPassword() {
        const c = this.config;
        const url = new URL(c.url.replace(/\/$/, '') +
            '/realms/' +
            encodeURIComponent(c.realm) +
            '/login-actions/reset-credentials', window.location.origin);
        url.searchParams.set('client_id', c.clientId);
        window.location.assign(url.toString());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: AuthService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: AuthService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: AuthService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const authInterceptor = (request, next) => {
    if (!request.url.startsWith('/api/v1/studio/'))
        return next(request);
    const auth = inject(AuthService);
    const team = request.headers.get('X-Runloom-Team') || auth.teamId();
    return from(auth.bearer()).pipe(switchMap((token) => next(request.clone({
        setHeaders: { Authorization: 'Bearer ' + token, 'X-Runloom-Team': team },
    }))));
};

class DialogService {
    active = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    open(owner, kind, message, options) {
        // Never queue destructive actions behind another confirmation.
        if (this.active())
            return Promise.resolve(null);
        return new Promise(resolve => this.active.set({ ...options, id: Symbol(), owner, kind, message, resolve }));
    }
    finish(id, value) {
        const request = this.active();
        if (!request || request.id !== id)
            return;
        this.active.set(null);
        request.resolve(value);
    }
    cancel(owner) {
        const request = this.active();
        if (request?.owner === owner)
            this.finish(request.id, null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: DialogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: DialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: DialogService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/** Pending decisions belong to the requesting screen, not its next replacement. */
function injectDialogs() {
    const service = inject(DialogService);
    const owner = Symbol();
    let destroyed = false;
    inject(DestroyRef).onDestroy(() => { destroyed = true; service.cancel(owner); });
    return {
        confirm: async (message, options = {}) => !destroyed && await service.open(owner, 'confirm', message, options) === true,
        prompt: async (message, options = {}) => {
            const result = destroyed ? null : await service.open(owner, 'prompt', message, options);
            return typeof result === 'string' ? result : null;
        },
        cancel: () => service.cancel(owner),
    };
}

class Dialogs {
    dialogs = inject(DialogService);
    value = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    error = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    element = viewChild('modal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "element" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const request = this.dialogs.active();
            const modal = this.element()?.nativeElement;
            if (!modal)
                return;
            if (!request) {
                if (modal.open)
                    modal.close();
                return;
            }
            this.value.set(request.initialValue ?? '');
            this.error.set('');
            queueMicrotask(() => {
                if (this.dialogs.active()?.id !== request.id || !modal.isConnected)
                    return;
                if (!modal.open)
                    modal.showModal();
                const target = modal.querySelector(request.kind === 'prompt' ? 'input' : '[data-testid="dialog-cancel"]');
                target?.focus();
                if (target instanceof HTMLInputElement)
                    target.select();
            });
        });
    }
    cancel(event) {
        event?.preventDefault();
        const request = this.dialogs.active();
        if (request)
            this.dialogs.finish(request.id, null);
    }
    trapFocus(event) {
        if (event.key !== 'Tab')
            return;
        const targets = this.element()?.nativeElement.querySelectorAll('input, button');
        if (!targets?.length)
            return;
        const first = targets[0], last = targets[targets.length - 1];
        if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
        }
        else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
        }
    }
    submit() {
        const request = this.dialogs.active();
        if (!request)
            return;
        if (request.kind === 'prompt') {
            const value = this.value().trim();
            if (!value || [...value].length > 80 || /\p{Cc}/u.test(value)) {
                this.error.set('Enter a project name between 1 and 80 characters, without control characters.');
                return;
            }
            this.dialogs.finish(request.id, value);
        }
        else
            this.dialogs.finish(request.id, true);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: Dialogs, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.5", type: Dialogs, isStandalone: true, selector: "runloom-dialogs", viewQueries: [{ propertyName: "element", first: true, predicate: ["modal"], descendants: true, isSignal: true }], ngImport: i0, template: "<dialog #modal aria-modal=\"true\" aria-labelledby=\"dialog-title\" aria-describedby=\"dialog-message\" (cancel)=\"cancel($event)\" (keydown)=\"trapFocus($event)\">\n  @if (dialogs.active(); as request) {\n    <form (ngSubmit)=\"submit()\" novalidate>\n      <div class=\"dialog-heading\">\n        <span class=\"dialog-icon\" aria-hidden=\"true\" [class.danger]=\"request.danger\">{{ request.kind === 'prompt' ? '+' : '?' }}</span>\n        <h2 id=\"dialog-title\">{{ request.title || 'Confirm action' }}</h2>\n      </div>\n      <p id=\"dialog-message\">{{ request.message }}</p>\n      @if (request.kind === 'prompt') {\n        <label for=\"dialog-input\">Project name</label>\n        <input id=\"dialog-input\" name=\"dialog-input\" [ngModel]=\"value()\" (ngModelChange)=\"value.set($event); error.set('')\" autocomplete=\"off\" [attr.aria-invalid]=\"error() ? 'true' : null\" [attr.aria-describedby]=\"error() ? 'dialog-error' : null\" />\n        @if (error()) { <p id=\"dialog-error\" class=\"error\" role=\"alert\">{{ error() }}</p> }\n      }\n      <div class=\"actions\">\n        <button type=\"button\" data-testid=\"dialog-cancel\" (click)=\"cancel()\">{{ request.cancelText || 'Cancel' }}</button>\n        <button type=\"submit\" data-testid=\"dialog-confirm\" class=\"primary\" [class.danger]=\"request.danger\">{{ request.confirmText || 'Confirm' }}</button>\n      </div>\n    </form>\n  }\n</dialog>\n", styles: [":host{display:contents}dialog{box-sizing:border-box;width:min(480px,100vw - 32px);max-height:calc(100dvh - 32px);padding:28px;border:1px solid var(--rl-border);border-radius:18px;color:var(--rl-ink);background:var(--rl-surface);box-shadow:var(--rl-shadow-overlay);font:14px/1.55 var(--rl-font)}dialog::backdrop{background:color-mix(in srgb,var(--rl-scrim) 45%,transparent);-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}.dialog-heading{display:flex;gap:12px;align-items:center}.dialog-icon{display:grid;place-items:center;flex:0 0 36px;height:36px;border-radius:10px;background:var(--rl-soft);color:var(--rl-accent);font-size:20px;font-weight:700}.dialog-icon.danger{background:var(--rl-soft);color:var(--rl-danger)}h2{margin:0;font-size:20px;line-height:1.3}p{margin:18px 0;color:var(--rl-secondary);overflow-wrap:anywhere}label{display:block;margin-bottom:6px;font-weight:600}input{box-sizing:border-box;width:100%;padding:11px 12px;border:1px solid var(--rl-muted);border-radius:8px;font:inherit}.actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:10px;margin-top:26px}button{min-height:42px;padding:9px 18px;border:1px solid var(--rl-border);border-radius:8px;background:var(--rl-surface);color:var(--rl-accent);font:inherit;font-weight:600;cursor:pointer}button:hover{background:var(--rl-soft)}button.primary{background:var(--rl-accent);border-color:var(--rl-accent);color:var(--rl-on-accent)}button.primary:hover{background:var(--rl-accent-hover)}button.primary.danger{background:var(--rl-danger);border-color:var(--rl-danger)}button.primary.danger:hover{background:var(--rl-danger)}button:focus-visible,input:focus-visible{outline:3px solid var(--rl-accent);outline-offset:3px}.error{color:var(--rl-danger);margin:8px 0 0;font-size:13px}@media(max-width:420px){dialog{padding:22px}.actions button{flex:1}}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: Dialogs, decorators: [{
            type: Component,
            args: [{ selector: 'runloom-dialogs', imports: [FormsModule], template: "<dialog #modal aria-modal=\"true\" aria-labelledby=\"dialog-title\" aria-describedby=\"dialog-message\" (cancel)=\"cancel($event)\" (keydown)=\"trapFocus($event)\">\n  @if (dialogs.active(); as request) {\n    <form (ngSubmit)=\"submit()\" novalidate>\n      <div class=\"dialog-heading\">\n        <span class=\"dialog-icon\" aria-hidden=\"true\" [class.danger]=\"request.danger\">{{ request.kind === 'prompt' ? '+' : '?' }}</span>\n        <h2 id=\"dialog-title\">{{ request.title || 'Confirm action' }}</h2>\n      </div>\n      <p id=\"dialog-message\">{{ request.message }}</p>\n      @if (request.kind === 'prompt') {\n        <label for=\"dialog-input\">Project name</label>\n        <input id=\"dialog-input\" name=\"dialog-input\" [ngModel]=\"value()\" (ngModelChange)=\"value.set($event); error.set('')\" autocomplete=\"off\" [attr.aria-invalid]=\"error() ? 'true' : null\" [attr.aria-describedby]=\"error() ? 'dialog-error' : null\" />\n        @if (error()) { <p id=\"dialog-error\" class=\"error\" role=\"alert\">{{ error() }}</p> }\n      }\n      <div class=\"actions\">\n        <button type=\"button\" data-testid=\"dialog-cancel\" (click)=\"cancel()\">{{ request.cancelText || 'Cancel' }}</button>\n        <button type=\"submit\" data-testid=\"dialog-confirm\" class=\"primary\" [class.danger]=\"request.danger\">{{ request.confirmText || 'Confirm' }}</button>\n      </div>\n    </form>\n  }\n</dialog>\n", styles: [":host{display:contents}dialog{box-sizing:border-box;width:min(480px,100vw - 32px);max-height:calc(100dvh - 32px);padding:28px;border:1px solid var(--rl-border);border-radius:18px;color:var(--rl-ink);background:var(--rl-surface);box-shadow:var(--rl-shadow-overlay);font:14px/1.55 var(--rl-font)}dialog::backdrop{background:color-mix(in srgb,var(--rl-scrim) 45%,transparent);-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}.dialog-heading{display:flex;gap:12px;align-items:center}.dialog-icon{display:grid;place-items:center;flex:0 0 36px;height:36px;border-radius:10px;background:var(--rl-soft);color:var(--rl-accent);font-size:20px;font-weight:700}.dialog-icon.danger{background:var(--rl-soft);color:var(--rl-danger)}h2{margin:0;font-size:20px;line-height:1.3}p{margin:18px 0;color:var(--rl-secondary);overflow-wrap:anywhere}label{display:block;margin-bottom:6px;font-weight:600}input{box-sizing:border-box;width:100%;padding:11px 12px;border:1px solid var(--rl-muted);border-radius:8px;font:inherit}.actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:10px;margin-top:26px}button{min-height:42px;padding:9px 18px;border:1px solid var(--rl-border);border-radius:8px;background:var(--rl-surface);color:var(--rl-accent);font:inherit;font-weight:600;cursor:pointer}button:hover{background:var(--rl-soft)}button.primary{background:var(--rl-accent);border-color:var(--rl-accent);color:var(--rl-on-accent)}button.primary:hover{background:var(--rl-accent-hover)}button.primary.danger{background:var(--rl-danger);border-color:var(--rl-danger)}button.primary.danger:hover{background:var(--rl-danger)}button:focus-visible,input:focus-visible{outline:3px solid var(--rl-accent);outline-offset:3px}.error{color:var(--rl-danger);margin:8px 0 0;font-size:13px}@media(max-width:420px){dialog{padding:22px}.actions button{flex:1}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { element: [{ type: i0.ViewChild, args: ['modal', { isSignal: true }] }] } });

/** Shared feedback surface. Errors and inline guidance never disappear on a timer. */
class Notice {
    message = '';
    title = '';
    tone = 'info';
    floating = false;
    dismissible = true;
    revision = 0;
    dismissLabel = 'Dismiss notification';
    dismissed = new EventEmitter();
    element = inject((ElementRef));
    cd = inject(ChangeDetectorRef);
    timer;
    remaining = 6000;
    started = 0;
    hovered = false;
    focused = false;
    get heading() {
        return this.title || { success: 'All set', error: 'Something needs your attention', info: 'Good to know', warning: 'Before you continue' }[this.tone];
    }
    get timed() { return this.floating && this.dismissible && this.tone === 'success'; }
    get paused() { return this.hovered || this.focused; }
    ngOnChanges() { this.clear(); this.remaining = 6000; this.resume(); }
    ngOnDestroy() { this.clear(); }
    close() { this.clear(); this.dismissed.emit(); this.cd.markForCheck(); }
    hover(value) { this.hovered = value; this.updateTimer(); }
    focus(value, event) {
        if (!value && event?.relatedTarget instanceof Node && this.element.nativeElement.contains(event.relatedTarget))
            return;
        this.focused = value;
        this.updateTimer();
    }
    updateTimer() {
        if (this.paused) {
            if (this.timer !== undefined)
                this.remaining = Math.max(0, this.remaining - (performance.now() - this.started));
            this.clear();
        }
        else
            this.resume();
    }
    resume() {
        if (!this.timed || this.paused || this.timer !== undefined)
            return;
        this.started = performance.now();
        this.timer = setTimeout(() => this.close(), this.remaining);
    }
    clear() { if (this.timer !== undefined)
        clearTimeout(this.timer); this.timer = undefined; }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: Notice, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.5", type: Notice, isStandalone: true, selector: "runloom-notice", inputs: { message: "message", title: "title", tone: "tone", floating: "floating", dismissible: "dismissible", revision: "revision", dismissLabel: "dismissLabel" }, outputs: { dismissed: "dismissed" }, host: { properties: { "class.toast": "floating", "attr.data-tone": "tone" } }, usesOnChanges: true, ngImport: i0, template: "<section class=\"notice-card\" (mouseenter)=\"hover(true)\" (mouseleave)=\"hover(false)\" (focusin)=\"focus(true)\" (focusout)=\"focus(false, $event)\">\n  <span class=\"notice-icon\" aria-hidden=\"true\">\n    <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n      @if (tone === 'success') { <path d=\"m6 12 4 4 8-8\" /> }\n      @else if (tone === 'error') { <path d=\"m8 8 8 8M16 8l-8 8\" /><circle cx=\"12\" cy=\"12\" r=\"9\" /> }\n      @else if (tone === 'warning') { <path d=\"m12 3 10 18H2L12 3Z M12 9v4m0 4h.01\" /> }\n      @else { <circle cx=\"12\" cy=\"12\" r=\"9\" /><path d=\"M12 11v6m0-10h.01\" /> }\n    </svg>\n  </span>\n  <div class=\"notice-copy\" [attr.role]=\"tone === 'error' ? 'alert' : 'status'\" aria-atomic=\"true\">\n    <strong>{{ heading }}</strong>\n    <p>{{ message }}</p>\n  </div>\n  @if (dismissible) {\n    <button class=\"notice-close\" type=\"button\" [attr.aria-label]=\"dismissLabel\" (click)=\"close()\">\n      <svg aria-hidden=\"true\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"><path d=\"m7 7 10 10M17 7 7 17\" /></svg>\n    </button>\n  }\n</section>\n", styles: [":host{--accent: var(--rl-accent);--tint: var(--rl-soft);display:block;min-width:0;margin:12px 0;font:13px/1.5 var(--rl-font)}:host([data-tone=success]){--accent: var(--rl-success);--tint: var(--rl-success-soft)}:host([data-tone=error]){--accent: var(--rl-danger);--tint: var(--rl-danger-soft)}:host([data-tone=warning]){--accent: var(--rl-warning);--tint: var(--rl-warning-soft)}.notice-card{box-sizing:border-box;display:flex;align-items:flex-start;gap:12px;padding:16px;border:1px solid var(--rl-divider);border-radius:12px;background:var(--rl-surface);color:var(--rl-ink);box-shadow:0 2px 4px color-mix(in srgb,var(--rl-scrim) 2%,transparent)}.notice-icon{display:grid;place-items:center;flex:0 0 32px;height:32px;border-radius:10px;color:var(--accent);background:var(--tint)}svg{display:block;width:20px;height:20px}.notice-copy{flex:1;min-width:0;overflow-wrap:anywhere}strong{display:block;font-size:13px;font-weight:650;line-height:1.5;color:var(--rl-ink)}p{margin:3px 0 0;color:var(--rl-secondary);font-size:12px;line-height:1.65;white-space:pre-wrap;max-height:min(240px,35dvh);overflow-y:auto}.notice-close{display:grid;place-items:center;flex:0 0 32px;height:32px;padding:0;margin:-4px -4px 0 0;color:var(--rl-muted);border:0;border-radius:7px;background:transparent;cursor:pointer}.notice-close:hover{color:var(--rl-ink);background:var(--rl-soft)}.notice-close:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.notice-close svg{width:16px;height:16px}:host.toast{position:fixed;z-index:65;right:max(24px,env(safe-area-inset-right));bottom:max(24px,env(safe-area-inset-bottom));width:min(420px,100vw - 32px);margin:0;animation:notice-enter .18s ease-out}:host.toast .notice-card{border-color:var(--rl-divider);box-shadow:0 8px 32px color-mix(in srgb,var(--rl-scrim) 9%,transparent),0 2px 8px color-mix(in srgb,var(--rl-scrim) 3%,transparent)}@keyframes notice-enter{0%{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}@media(max-width:600px){:host.toast{right:16px;bottom:max(16px,env(safe-area-inset-bottom))}.notice-card{padding:14px;gap:10px}.notice-close{flex-basis:40px;height:40px}}@media(prefers-reduced-motion:reduce){:host.toast{animation:none}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: Notice, decorators: [{
            type: Component,
            args: [{ selector: 'runloom-notice', host: { '[class.toast]': 'floating', '[attr.data-tone]': 'tone' }, template: "<section class=\"notice-card\" (mouseenter)=\"hover(true)\" (mouseleave)=\"hover(false)\" (focusin)=\"focus(true)\" (focusout)=\"focus(false, $event)\">\n  <span class=\"notice-icon\" aria-hidden=\"true\">\n    <svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n      @if (tone === 'success') { <path d=\"m6 12 4 4 8-8\" /> }\n      @else if (tone === 'error') { <path d=\"m8 8 8 8M16 8l-8 8\" /><circle cx=\"12\" cy=\"12\" r=\"9\" /> }\n      @else if (tone === 'warning') { <path d=\"m12 3 10 18H2L12 3Z M12 9v4m0 4h.01\" /> }\n      @else { <circle cx=\"12\" cy=\"12\" r=\"9\" /><path d=\"M12 11v6m0-10h.01\" /> }\n    </svg>\n  </span>\n  <div class=\"notice-copy\" [attr.role]=\"tone === 'error' ? 'alert' : 'status'\" aria-atomic=\"true\">\n    <strong>{{ heading }}</strong>\n    <p>{{ message }}</p>\n  </div>\n  @if (dismissible) {\n    <button class=\"notice-close\" type=\"button\" [attr.aria-label]=\"dismissLabel\" (click)=\"close()\">\n      <svg aria-hidden=\"true\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"><path d=\"m7 7 10 10M17 7 7 17\" /></svg>\n    </button>\n  }\n</section>\n", styles: [":host{--accent: var(--rl-accent);--tint: var(--rl-soft);display:block;min-width:0;margin:12px 0;font:13px/1.5 var(--rl-font)}:host([data-tone=success]){--accent: var(--rl-success);--tint: var(--rl-success-soft)}:host([data-tone=error]){--accent: var(--rl-danger);--tint: var(--rl-danger-soft)}:host([data-tone=warning]){--accent: var(--rl-warning);--tint: var(--rl-warning-soft)}.notice-card{box-sizing:border-box;display:flex;align-items:flex-start;gap:12px;padding:16px;border:1px solid var(--rl-divider);border-radius:12px;background:var(--rl-surface);color:var(--rl-ink);box-shadow:0 2px 4px color-mix(in srgb,var(--rl-scrim) 2%,transparent)}.notice-icon{display:grid;place-items:center;flex:0 0 32px;height:32px;border-radius:10px;color:var(--accent);background:var(--tint)}svg{display:block;width:20px;height:20px}.notice-copy{flex:1;min-width:0;overflow-wrap:anywhere}strong{display:block;font-size:13px;font-weight:650;line-height:1.5;color:var(--rl-ink)}p{margin:3px 0 0;color:var(--rl-secondary);font-size:12px;line-height:1.65;white-space:pre-wrap;max-height:min(240px,35dvh);overflow-y:auto}.notice-close{display:grid;place-items:center;flex:0 0 32px;height:32px;padding:0;margin:-4px -4px 0 0;color:var(--rl-muted);border:0;border-radius:7px;background:transparent;cursor:pointer}.notice-close:hover{color:var(--rl-ink);background:var(--rl-soft)}.notice-close:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.notice-close svg{width:16px;height:16px}:host.toast{position:fixed;z-index:65;right:max(24px,env(safe-area-inset-right));bottom:max(24px,env(safe-area-inset-bottom));width:min(420px,100vw - 32px);margin:0;animation:notice-enter .18s ease-out}:host.toast .notice-card{border-color:var(--rl-divider);box-shadow:0 8px 32px color-mix(in srgb,var(--rl-scrim) 9%,transparent),0 2px 8px color-mix(in srgb,var(--rl-scrim) 3%,transparent)}@keyframes notice-enter{0%{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}@media(max-width:600px){:host.toast{right:16px;bottom:max(16px,env(safe-area-inset-bottom))}.notice-card{padding:14px;gap:10px}.notice-close{flex-basis:40px;height:40px}}@media(prefers-reduced-motion:reduce){:host.toast{animation:none}}\n"] }]
        }], propDecorators: { message: [{
                type: Input
            }], title: [{
                type: Input
            }], tone: [{
                type: Input
            }], floating: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], revision: [{
                type: Input
            }], dismissLabel: [{
                type: Input
            }], dismissed: [{
                type: Output
            }] } });

class UiIcon {
    name = 'workflow';
    paths = {
        'chevron-down': 'm6 9 6 6 6-6',
        'chevron-up': 'm6 15 6-6 6 6',
        minus: 'M5 12h14',
        check: 'm5 12 4 4L19 6',
        play: 'm8 5 11 7-11 7V5Z',
        copy: 'M9 9h12v12H9V9ZM15 9V3H3v12h6',
        target: 'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10ZM12 2v5m0 10v5M2 12h5m10 0h5',
        sun: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1',
        moon: 'M20 15A9 9 0 0 1 9 4a9 9 0 1 0 11 11Z',
        monitor: 'M3 4h18v13H3V4Zm9 13v4m-4 0h8',
        budget: 'M3 5h18v15H3V5Zm0 4h18m-6 4h6v4h-6v-4ZM6 2v3m12-3v3',
        analytics: 'M4 3v18h17M8 16v-4m5 4V8m5 8V5',
        sidebar: 'M4 3h16a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm4 0v18',
        workflow: 'M3 3h6v6H3Zm12 12h6v6h-6ZM9 6h6a3 3 0 0 1 3 3v6M6 9v6a3 3 0 0 0 3 3h6',
        plus: 'M12 5v14M5 12h14',
        runs: 'm9 6 10 6-10 6V6ZM4 5v14',
        calendar: 'M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Zm2-3v6m10-6v6M3 11h18m-14 4h2m4 0h2m-8 3h2',
        team: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m20 0v-2a4 4 0 0 0-3-3.87M9 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm8 0a4 4 0 0 1 0 8',
        building: 'M4 21V5l8-3v19m0-14h8v14M2 21h20M7 7h1m-1 4h1m-1 4h1m8-4h1m-1 4h1',
        key: 'M14 4a6 6 0 1 0 6 6 6 6 0 0 0-6-6ZM10 14l-7 7m0-4v4h4m10-13h.01',
        shield: 'm12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6l8-3Zm-3 9 2 2 4-4',
        logout: 'M9 4H4v16h5m6-13 5 5-5 5M8 12h12',
        arrow: 'M5 12h14m-6-6 6 6-6 6',
        search: 'M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm5 12 6 6',
        folder: 'M3 7V5h6l2 3h10v12H3V7Z',
        close: 'm6 6 12 12M18 6 6 18',
        edit: 'm15 4 5 5M4 20l5-1L21 7l-5-5L4 14v6Z',
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: UiIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.5", type: UiIcon, isStandalone: true, selector: "runloom-icon", inputs: { name: "name" }, ngImport: i0, template: "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path [attr.d]=\"paths[name] || paths['workflow']\" /></svg>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex:none;width:var(--rl-icon-size, 20px);height:var(--rl-icon-size, 20px);vertical-align:middle;line-height:1}svg{display:block;flex:none;width:100%;height:100%}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: UiIcon, decorators: [{
            type: Component,
            args: [{ selector: 'runloom-icon', template: "<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.65\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path [attr.d]=\"paths[name] || paths['workflow']\" /></svg>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex:none;width:var(--rl-icon-size, 20px);height:var(--rl-icon-size, 20px);vertical-align:middle;line-height:1}svg{display:block;flex:none;width:100%;height:100%}\n"] }]
        }], propDecorators: { name: [{
                type: Input
            }] } });

const storageKey = 'runloom.theme';
const normalize = (value) => value === 'light' || value === 'dark' ? value : 'system';
class ThemeService {
    media = window.matchMedia('(prefers-color-scheme: dark)');
    preference = signal('system', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "preference" }] : /* istanbul ignore next */ []));
    resolved = signal('light', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolved" }] : /* istanbul ignore next */ []));
    frame = 0;
    constructor() {
        try {
            this.preference.set(normalize(localStorage.getItem(storageKey)));
        }
        catch { }
        this.apply();
        const systemChanged = () => this.apply();
        const storageChanged = (event) => {
            if (event.key === storageKey || event.key === null) {
                this.preference.set(normalize(event.newValue));
                this.apply();
            }
        };
        this.media.addEventListener('change', systemChanged);
        window.addEventListener('storage', storageChanged);
        inject(DestroyRef).onDestroy(() => {
            cancelAnimationFrame(this.frame);
            document.documentElement.classList.remove('theme-changing');
            this.media.removeEventListener('change', systemChanged);
            window.removeEventListener('storage', storageChanged);
        });
    }
    setPreference(value) {
        this.preference.set(normalize(value));
        try {
            localStorage.setItem(storageKey, this.preference());
        }
        catch { }
        this.apply();
    }
    apply() {
        const theme = this.preference() === 'system'
            ? (this.media.matches ? 'dark' : 'light') : this.preference();
        this.resolved.set(theme);
        const root = document.documentElement;
        if (root.dataset['theme'] !== theme) {
            cancelAnimationFrame(this.frame);
            root.classList.add('theme-changing');
            root.dataset['theme'] = theme;
            this.frame = requestAnimationFrame(() => {
                this.frame = requestAnimationFrame(() => root.classList.remove('theme-changing'));
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: ThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: ThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class ThemePicker {
    compact = false;
    panel;
    trigger;
    theme = inject(ThemeService);
    options = [
        { value: 'light', label: 'Light', icon: 'sun' },
        { value: 'dark', label: 'Dark', icon: 'moon' },
        { value: 'system', label: 'System', icon: 'monitor' },
    ];
    left = 12;
    bottom = 80;
    position(button) {
        const rect = button.getBoundingClientRect();
        this.left = Math.max(8, Math.min(rect.left, window.innerWidth - 220));
        this.bottom = Math.max(8, Math.min(window.innerHeight - rect.top + 8, window.innerHeight - 250));
    }
    choose(value) {
        this.theme.setPreference(value);
        this.panel?.nativeElement.hidePopover();
        this.trigger?.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: ThemePicker, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.5", type: ThemePicker, isStandalone: true, selector: "runloom-theme-picker", inputs: { compact: "compact" }, viewQueries: [{ propertyName: "panel", first: true, predicate: ["panel"], descendants: true }, { propertyName: "trigger", first: true, predicate: ["trigger"], descendants: true }], ngImport: i0, template: "<button #trigger type=\"button\" class=\"trigger\" [class.compact]=\"compact\" popovertarget=\"appearance-options\"\n      [attr.aria-label]=\"'Appearance: ' + theme.preference()\" (click)=\"position(trigger)\">\n      <runloom-icon [name]=\"theme.resolved() === 'dark' ? 'moon' : 'sun'\" />\n      @if (!compact) { <span>Appearance</span><small>{{ theme.preference() }}</small> }\n    </button>\n    <div #panel id=\"appearance-options\" popover=\"auto\" [style.left.px]=\"left\" [style.bottom.px]=\"bottom\">\n      <strong>Appearance</strong>\n      <div role=\"group\" aria-label=\"Color theme\">\n        @for (option of options; track option.value) {\n          <button type=\"button\" [attr.aria-pressed]=\"theme.preference() === option.value\"\n            (click)=\"choose(option.value)\">\n            <runloom-icon [name]=\"option.icon\" /><span>{{ option.label }}</span>\n            @if (theme.preference() === option.value) { <span aria-hidden=\"true\">\u2713</span> }\n          </button>\n        }\n      </div>\n      <p>System follows your device.</p>\n    </div>\n", styles: [":host{display:block}button{font:inherit;cursor:pointer;border:0;border-radius:8px;display:flex;align-items:center;gap:10px}.trigger{width:100%;padding:10px;background:transparent;color:var(--rl-nav-text);font-size:12px;text-align:left}.trigger:hover{background:var(--rl-nav-hover)}.trigger.compact{justify-content:center;min-height:42px;gap:0}small{margin-left:auto;color:var(--rl-nav-muted);text-transform:capitalize;font-size:10px}[popover]{position:fixed;top:auto;right:auto;margin:0;width:204px;box-sizing:border-box;padding:10px;border:1px solid var(--rl-border);border-radius:12px;background:var(--rl-surface);color:var(--rl-ink);box-shadow:var(--rl-shadow-overlay)}strong{display:block;padding:5px 8px 10px;font-size:12px}[popover] button{width:100%;padding:10px 8px;background:transparent;color:var(--rl-secondary);font-size:13px}[popover] button span:first-of-type{flex:1;text-align:left}[popover] button:hover,[aria-pressed=true]{background:var(--rl-accent-soft)!important;color:var(--rl-accent)!important}p{margin:10px 8px 4px;color:var(--rl-muted);font-size:11px}\n"], dependencies: [{ kind: "component", type: UiIcon, selector: "runloom-icon", inputs: ["name"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: ThemePicker, decorators: [{
            type: Component,
            args: [{ selector: 'runloom-theme-picker', imports: [UiIcon], template: "<button #trigger type=\"button\" class=\"trigger\" [class.compact]=\"compact\" popovertarget=\"appearance-options\"\n      [attr.aria-label]=\"'Appearance: ' + theme.preference()\" (click)=\"position(trigger)\">\n      <runloom-icon [name]=\"theme.resolved() === 'dark' ? 'moon' : 'sun'\" />\n      @if (!compact) { <span>Appearance</span><small>{{ theme.preference() }}</small> }\n    </button>\n    <div #panel id=\"appearance-options\" popover=\"auto\" [style.left.px]=\"left\" [style.bottom.px]=\"bottom\">\n      <strong>Appearance</strong>\n      <div role=\"group\" aria-label=\"Color theme\">\n        @for (option of options; track option.value) {\n          <button type=\"button\" [attr.aria-pressed]=\"theme.preference() === option.value\"\n            (click)=\"choose(option.value)\">\n            <runloom-icon [name]=\"option.icon\" /><span>{{ option.label }}</span>\n            @if (theme.preference() === option.value) { <span aria-hidden=\"true\">\u2713</span> }\n          </button>\n        }\n      </div>\n      <p>System follows your device.</p>\n    </div>\n", styles: [":host{display:block}button{font:inherit;cursor:pointer;border:0;border-radius:8px;display:flex;align-items:center;gap:10px}.trigger{width:100%;padding:10px;background:transparent;color:var(--rl-nav-text);font-size:12px;text-align:left}.trigger:hover{background:var(--rl-nav-hover)}.trigger.compact{justify-content:center;min-height:42px;gap:0}small{margin-left:auto;color:var(--rl-nav-muted);text-transform:capitalize;font-size:10px}[popover]{position:fixed;top:auto;right:auto;margin:0;width:204px;box-sizing:border-box;padding:10px;border:1px solid var(--rl-border);border-radius:12px;background:var(--rl-surface);color:var(--rl-ink);box-shadow:var(--rl-shadow-overlay)}strong{display:block;padding:5px 8px 10px;font-size:12px}[popover] button{width:100%;padding:10px 8px;background:transparent;color:var(--rl-secondary);font-size:13px}[popover] button span:first-of-type{flex:1;text-align:left}[popover] button:hover,[aria-pressed=true]{background:var(--rl-accent-soft)!important;color:var(--rl-accent)!important}p{margin:10px 8px 4px;color:var(--rl-muted);font-size:11px}\n"] }]
        }], propDecorators: { compact: [{
                type: Input
            }], panel: [{
                type: ViewChild,
                args: ['panel']
            }], trigger: [{
                type: ViewChild,
                args: ['trigger']
            }] } });

/** Versioned UI contract. No tokens, credentials or feature implementation cross it. */
class WorkspaceBridge {
    workflow = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "workflow" }] : /* istanbul ignore next */ []));
    management = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "management" }] : /* istanbul ignore next */ []));
    toggleNavigation = new EventEmitter();
    host;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: WorkspaceBridge, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: WorkspaceBridge, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: WorkspaceBridge, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class RemoteLanding {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: RemoteLanding, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.5", type: RemoteLanding, isStandalone: true, selector: "app-root", ngImport: i0, template: "<main><h1>Runloom application remote</h1><p>This Angular application is available. Open Runloom Studio to use it with your authenticated workspace.</p></main>\n", styles: [":host{display:block;font:16px/1.6 system-ui;color:var(--rl-ink);background:var(--rl-canvas);min-height:100vh}main{max-width:640px;margin:auto;padding:80px 24px}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.5", ngImport: i0, type: RemoteLanding, decorators: [{
            type: Component,
            args: [{ selector: 'app-root', template: "<main><h1>Runloom application remote</h1><p>This Angular application is available. Open Runloom Studio to use it with your authenticated workspace.</p></main>\n", styles: [":host{display:block;font:16px/1.6 system-ui;color:var(--rl-ink);background:var(--rl-canvas);min-height:100vh}main{max-width:640px;margin:auto;padding:80px 24px}\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AuthService, DialogService, Dialogs, Notice, RemoteLanding, ThemePicker, ThemeService, UiIcon, WorkspaceBridge, authInterceptor, authReturnUrl, injectDialogs };
//# sourceMappingURL=runloom-studio-platform.mjs.map
