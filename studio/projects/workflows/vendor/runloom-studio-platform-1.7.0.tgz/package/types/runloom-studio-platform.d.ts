import * as _angular_core from '@angular/core';
import { OnChanges, OnDestroy, EventEmitter, ElementRef, TemplateRef } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';

interface Team {
    id: string;
    name: string;
    role: 'admin' | 'editor' | 'viewer';
}
interface Organization {
    id: string;
    name: string;
    role: 'owner' | 'admin' | 'member';
    teams: Team[];
}
interface Member {
    email: string;
    user_id: string;
    role: string;
}
interface AuthConfig {
    url: string;
    realm: string;
    clientId: string;
    googleEnabled: boolean;
}
interface Profile {
    user: {
        id: string;
        email: string;
        name: string;
    };
    organizations: Organization[];
}
declare class AuthService {
    private keycloak?;
    config?: AuthConfig;
    readonly ready: _angular_core.WritableSignal<boolean>;
    readonly signedIn: _angular_core.WritableSignal<boolean>;
    readonly profile: _angular_core.WritableSignal<Profile | undefined>;
    readonly organizationId: _angular_core.WritableSignal<string>;
    readonly teamId: _angular_core.WritableSignal<string>;
    readonly organizations: _angular_core.Signal<Organization[]>;
    readonly organization: _angular_core.Signal<Organization | undefined>;
    readonly team: _angular_core.Signal<Team | undefined>;
    readonly canEdit: _angular_core.Signal<boolean>;
    readonly orgAdmin: _angular_core.Signal<boolean>;
    readonly teamAdmin: _angular_core.Signal<boolean>;
    initialize(): Promise<void>;
    bearer(): Promise<string>;
    request<T>(path: string, body?: unknown, method?: string): Promise<T>;
    refresh(): Promise<void>;
    selectOrganization(id: string): void;
    selectTeam(id: string): void;
    login(google?: boolean): Promise<void>;
    register(): Promise<void>;
    logout(): Promise<void>;
    forgotPassword(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AuthService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AuthService>;
}

declare const authInterceptor: HttpInterceptorFn;

declare function authReturnUrl(current: string): string;

interface DialogOptions {
    title?: string;
    confirmText?: string;
    cancelText?: string;
    danger?: boolean;
    initialValue?: string;
}
interface DialogRequest extends DialogOptions {
    id: symbol;
    owner: symbol;
    kind: 'confirm' | 'prompt';
    message: string;
    resolve: (value: string | boolean | null) => void;
}
declare class DialogService {
    readonly active: _angular_core.WritableSignal<DialogRequest | null>;
    open(owner: symbol, kind: DialogRequest['kind'], message: string, options: DialogOptions): Promise<string | boolean | null>;
    finish(id: symbol, value: string | boolean | null): void;
    cancel(owner: symbol): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DialogService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DialogService>;
}
/** Pending decisions belong to the requesting screen, not its next replacement. */
declare function injectDialogs(): {
    confirm: (message: string, options?: DialogOptions) => Promise<boolean>;
    prompt: (message: string, options?: DialogOptions) => Promise<string | null>;
    cancel: () => void;
};

declare class Dialogs {
    readonly dialogs: DialogService;
    readonly value: _angular_core.WritableSignal<string>;
    readonly error: _angular_core.WritableSignal<string>;
    private readonly element;
    constructor();
    cancel(event?: Event): void;
    trapFocus(event: KeyboardEvent): void;
    submit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Dialogs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Dialogs, "runloom-dialogs", never, {}, {}, never, never, true, never>;
}

type NoticeTone = 'success' | 'error' | 'info' | 'warning';
/** Shared feedback surface. Errors and inline guidance never disappear on a timer. */
declare class Notice implements OnChanges, OnDestroy {
    message: string;
    title: string;
    tone: NoticeTone;
    floating: boolean;
    dismissible: boolean;
    revision: number;
    dismissLabel: string;
    dismissed: EventEmitter<void>;
    private readonly element;
    private readonly cd;
    private timer?;
    private remaining;
    private started;
    private hovered;
    private focused;
    get heading(): string;
    get timed(): boolean;
    get paused(): boolean;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    close(): void;
    hover(value: boolean): void;
    focus(value: boolean, event?: FocusEvent): void;
    private updateTimer;
    private resume;
    private clear;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Notice, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Notice, "runloom-notice", never, { "message": { "alias": "message"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tone": { "alias": "tone"; "required": false; }; "floating": { "alias": "floating"; "required": false; }; "dismissible": { "alias": "dismissible"; "required": false; }; "revision": { "alias": "revision"; "required": false; }; "dismissLabel": { "alias": "dismissLabel"; "required": false; }; }, { "dismissed": "dismissed"; }, never, never, true, never>;
}

declare class UiIcon {
    name: string;
    readonly paths: Record<string, string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiIcon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiIcon, "runloom-icon", never, { "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}

type ThemePreference = 'light' | 'dark' | 'system';
declare class ThemeService {
    private readonly media;
    readonly preference: _angular_core.WritableSignal<ThemePreference>;
    readonly resolved: _angular_core.WritableSignal<"light" | "dark">;
    private frame;
    constructor();
    setPreference(value: ThemePreference): void;
    private apply;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ThemeService>;
}

declare class ThemePicker {
    compact: boolean;
    panel?: ElementRef<HTMLElement>;
    trigger?: ElementRef<HTMLButtonElement>;
    readonly theme: ThemeService;
    readonly options: ({
        value: "light";
        label: string;
        icon: string;
    } | {
        value: "dark";
        label: string;
        icon: string;
    } | {
        value: "system";
        label: string;
        icon: string;
    })[];
    left: number;
    bottom: number;
    position(button: HTMLElement): void;
    choose(value: ThemePreference): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThemePicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ThemePicker, "runloom-theme-picker", never, { "compact": { "alias": "compact"; "required": false; }; }, {}, never, never, true, never>;
}

type ManagementSection = 'teams' | 'organization' | 'accounts' | 'secrets' | 'connections' | 'analytics' | 'budgets' | 'prompts' | 'runs' | 'schedules';
type ApplicationKind = 'workflows' | 'management';
interface WorkflowPort {
    /** Details-page scope, not the selected node or a run ID. No draft content crosses this contract. */
    readonly assistantContext?: {
        workflowId: string;
        name: string;
        saved: boolean;
        canApply?: boolean;
    };
    refreshAuthoringDraft?(workflowId: string): Promise<void>;
    /** Return to the dashboard after resolving dirty edits; false means navigation was blocked. */
    showDashboard?(): Promise<boolean>;
    workflowNavigation: TemplateRef<unknown>;
    toggleNavigation: EventEmitter<void>;
    confirmDiscardChanges(): Promise<boolean>;
    withConfirmedExit(action: () => Promise<void>): Promise<void>;
    openRun(): Promise<void>;
    openSchedules(): Promise<void>;
}
interface ManagementPort {
    busy: boolean;
    confirmDiscard(): Promise<boolean>;
    withConfirmedExit(action: () => Promise<void>): Promise<void>;
    loadMembers(): Promise<void>;
}
/** Versioned UI contract. No tokens, credentials or feature implementation cross it. */
declare class WorkspaceBridge {
    readonly workflow: _angular_core.WritableSignal<WorkflowPort | undefined>;
    readonly management: _angular_core.WritableSignal<ManagementPort | undefined>;
    readonly toggleNavigation: EventEmitter<void>;
    host?: {
        selectTeam(id: string): Promise<void>;
        openManagement(section?: ManagementSection): Promise<void>;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<WorkspaceBridge, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<WorkspaceBridge>;
}

declare class RemoteLanding {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RemoteLanding, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RemoteLanding, "app-root", never, {}, {}, never, never, true, never>;
}

export { AuthService, DialogService, Dialogs, Notice, RemoteLanding, ThemePicker, ThemeService, UiIcon, WorkspaceBridge, authInterceptor, authReturnUrl, injectDialogs };
export type { ApplicationKind, ManagementPort, ManagementSection, Member, NoticeTone, Organization, Team, ThemePreference, WorkflowPort };
//# sourceMappingURL=runloom-studio-platform.d.ts.map
